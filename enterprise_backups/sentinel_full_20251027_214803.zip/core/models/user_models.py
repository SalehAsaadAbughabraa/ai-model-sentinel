class UserRole:
    SUPER_ADMIN = "super_admin"
    DEVELOPER = "developer"
    ADMIN = "admin"
    USER = "user"
    SECURITY_ANALYST = "security_analyst"
    TENANT_ADMIN = "tenant_admin"
    AUDITOR = "auditor"
