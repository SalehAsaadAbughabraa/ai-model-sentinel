# User models for DynamicRuleEngine

class User:
    def __init__(self, username="admin", role="administrator", permissions=None):
        self.username = username
        self.role = role
        self.permissions = permissions or ["read", "write", "execute"]
    
    def has_permission(self, permission):
        return permission in self.permissions

class UserRole:
    DEVELOPER = "developer"
    ADMIN = "admin"
    USER = "user"
    SECURITY_ANALYST = "security_analyst"
    TENANT_ADMIN = "tenant_admin"
    AUDITOR = "auditor"
    
class UserStatus:
    ACTIVE = "active"
    INACTIVE = "inactive"
    SUSPENDED = "suspended"
    PENDING = "pending"

__all__ = ["User", "UserRole", "UserStatus"]
