# Version management - auto-generated from pyproject.toml
__version__ = "2.0.0"